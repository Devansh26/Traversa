A Pen created at CodePen.io. You can find this one at https://codepen.io/alessandropilastrini/pen/NPxbjP.

 "Hover the rainbow" is a simple hover effect for card and box element, 100% CSS!

https://dribbble.com/shots/1836986-Hover-The-Rainbow